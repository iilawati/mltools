import os
def main():
    os.system("clear")
    print("for Tools which benefit from having access to GPU hardware (1)\n"
          "for Hardware hacking tools (2)\n"
          "for Cryptography & Steganography tools (3)\n"
          "for fuzzing protocols tools (4)\n"
          "for Wi-Fi Tools (5)\n"
          "for bluetooth tools (6)\n"
          "for Radio-Frequency IDentification tools (7)\n"
          "for Software-Defined Radio tools (8)\n"
          "for Voice over IP tools (9)\n"
          "for resources which can be executed on a Windows hosts (10)\n"
          "for Environments for learning and practising on (11)\n"
          "to install all on one (12)\n"
          "to back to main menu (00)\n")
    choice()

def choice():
    c_random = int(input("enter your choice : "))
    if c_random == 1:
        gpu_tools()

    if c_random == 2:
        hardware_hacking()

    if c_random == 3:
        crypto_stego()

    if c_random == 4:
        fuzzing()

    if c_random == 5:
        WiFi()

    if c_random == 6:
        bluetooth()

    if c_random == 7:
        Radio()

    if c_random == 8:
        Software_Radio()

    if c_random == 9:
        Voice_over_IP()

    if c_random == 10:
        windows_resources()

    if c_random == 11:
        kali_linux_labs()

    if c_random == 12:
        All()

    if c_random == 00:
        main_menu()
def gpu_tools():
    c_input = str(input("if you want to install Tools which benefit from having access to GPU hardware write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-gpu -y")
        main()
    else:
        main()

def hardware_hacking():
    c_input = str(input("if you want to install Hardware hacking tools write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-hardware -y")
        main()
    else:
        main()
def crypto_stego():
    c_input = str(input("if you want to install Tools based around Cryptography & Steganography write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-crypto-stego -y")
        main()
    else:
        main()

def fuzzing():
    c_input = str(input("if you want to install fuzzing protocols tools write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-fuzzing -y")
        main()
    else:
        main()

def WiFi():
    c_input = str(input("if you want to install Wi-Fi Tools write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-802-11 -y")
        main()
    else:
        main()

def bluetooth():
    c_input = str(input("if you want to install bluetooth tools write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-bluetooth -y")
        main()
    else:
        main()

def Radio():
    c_input = str(input("if you want to install Radio-Frequency IDentification tools write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-rfid -y")
        main()
    else:
        main()

def Software_Radio():
    c_input = str(input("if you want to install Software-Defined Radio tools write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-sdr -y")
        main()
    else:
        main()

def Voice_over_IP():
    c_input = str(input("if you want to install Voice over IP tools write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-voip -y")
        main()
    else:
        main()

def windows_resources():
    c_input = str(input("if you want to install Any resources which can be executed on a Windows hosts write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-tools-windows-resources -y")
        main()
    else:
        main()

def kali_linux_labs():
    c_input = str(input("if you want to install Environments for learning and practising on write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt install kali-linux-labs -y")
        main()
    else:
        main()

def All():
    c_input = str(input("if you want to install all menu write [yes] if not [no] : "))
    if c_input == "yes":
        os.system("sudo apt update -y && sudo apt install kali-linux-labs -y && sudo apt install kali-tools-windows-resources -y && sudo apt install kali-tools-voip -y && sudo apt install kali-tools-sdr -y && sudo apt install kali-tools-rfid -y && sudo apt install kali-tools-bluetooth -y && sudo apt install kali-tools-802-11 -y && sudo apt install kali-tools-fuzzing -y && sudo apt install kali-tools-crypto-stego -y && sudo apt install kali-tools-hardware -y && sudo apt install kali-tools-gpu -y ")
        main()
    else:
        main()

def main_menu():
    from mltools import main

main()