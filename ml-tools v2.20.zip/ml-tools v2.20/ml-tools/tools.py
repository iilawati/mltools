import os
import webbrowser

def tools_main():

    os.system("clear")

    print("network tools (1)\n"
          "windows system hacking tools (2)\n"
          "web scan tools (3)\n"
          "mobile system hacking tools (4)\n"
          "information gathering tools (5)\n"
          "facebook cracker (6)\n"
          "world list (7)")
    print("\n")
    random_y()


def random_y():

    random_t = input(str("enter the package number : "))
    if random_t == str("1"):
        network_tools()
    if random_t == str("2"):
      import windows_hacking

def network_tools():
    os.system("clear")
    print("p0f , for download [1] for info about this tool [p0f_info]")
    print("argus , for download [2] for info about this tool [argus_info]")
    print("splunk , for download [3] for info about this tool [splunk_info]")


    print("\n")

    tools_number = input(str("enter the tools number or [name]_info : "))
    if tools_number == str("1"):
        url = "https://lcamtuf.coredump.cx/p0f3/releases/p0f-3.09b.tgz"
        webbrowser.open(url)
        x_conf = str(input("do you to download more tools [yes] if you want [no] for mai menu : "))
        if x_conf == str("yes"):
            network_tools()

        else:
            from mltools import main

    if tools_number == str("p0f_info"):
        print("\nP0f is a tool that utilizes an array of sophisticated, purely passive traffic fingerprinting mechanisms to identify the players behind any incidental TCP/IP communications (often as little as a single normal SYN) without interfering in any way. Version 3 is a complete rewrite of the original codebase, incorporating a significant number of improvements to network-level fingerprinting, and introducing the ability to reason about application-level payloads (e.g., HTTP)\n"
              "Some of p0f's capabilities include:\n"
              "Highly scalable and extremely fast identification of the operating system and software on both endpoints of a vanilla TCP connection - especially in settings where NMap probes are blocked, too slow, unreliable, or would simply set off alarms\nMeasurement of system uptime and network hookup, distance (including topology behind NAT or packet filters), user language preferences, and so on.\nAutomated detection of connection sharing / NAT, load balancing, and application-level proxying setups.\nDetection of clients and servers that forge declarative statements such as X-Mailer or User-Agent.\n"
              "The tool can be operated in the foreground or as a daemon, and offers a simple real-time API for third-party components that wish to obtain additional information about the actors they are talking to.\n")
        print("\n")

        q_install = input(str("if want to download this tool enter [download] if not [no] : "))

        if q_install == str("download"):
            url="https://lcamtuf.coredump.cx/p0f3/releases/p0f-3.09b.tgz"
            webbrowser.open(url)
            x_conf = str(input("do you to download more tools [yes] if you want [no] for mai menu : "))
            if x_conf == str("yes"):
                network_tools()

            else:
                from mltools import main
        else:
            tools_main()
    if tools_number == str("2"):
        url = "http://qosient.com/argus/src/argus-3.0.8.2.tar.gz"
        webbrowser.open(url)
        x_conf = str(input("do you to download more tools [yes] if you want [no] for mai menu : "))
        if x_conf == str("yes"):
            network_tools()

        else:
            from mltools import main

    if tools_number == str("argus_info"):
        print("\nArgus is the first network flow system, developed by Carter Bullard in the early 1980's at Georgia Tech, and adopted for cyber security at Carnegie Mellon's Software Engineering Institute in the late 1980's.  Network flow technology has become a critical part of modern cyber security and Argus is being used in some of the most important networks in the world."
          "\nThe Argus Project is a privately funded open source project focused on proof of concept demonstrations of all aspects of large scale network awareness derived from network flow data.  Argus, attempts to be the bleeding edge of network flow technology, processing packets really fast, either on the wire or in captures, into the richest network flow data available. The Argus system attempts ti address a large number of the issues of network flow data; scale, performance, applicability, privacy and utility."
          "\nAt the heart is Argus Data, which is a superset of all the various flow data technologies today, NetFlow, Jflow, Qflow, Kflow, IPFIX, and the historical flow-tools.  It's models, formats, and attributes are designed to support network operations, performance and cyber security, answering questions regarding historical, current and future network activity and use.  The data has over 145 attributes covering network identification, services, resource utilization, packet dynamics, network activity metadata and content."
          "\nIf you are interested in using argus, grab the code and dive in.  If you would like to participate in the development of Argus, sign up to the mailing lists, grab the code and start playing with what we have, so you can see where you can contribute.")        
        print("\n")

        q_install2 =input(str("if want to download this tool enter [download] if not [no] : "))
        if q_install2 == str("download"):
            url = "http://qosient.com/argus/src/argus-3.0.8.2.tar.gz"
            x_conf = str(input("do you to download more tools [yes] if you want [no] for mai menu : "))
            if x_conf == str("yes"):
                network_tools()

            else:
                from mltools import main
        else:
          network_tools()

    if tools_number == str("3"):
        url = "https://mega.nz/file/NbhBBRjQ#tvVIx5h6qTn2gyF9cEWKXe-3cP96A6lFyAMR6qZZN9c"
        webbrowser.open(url)
        x_conf = str(input("do you to download more tools [yes] if you want [no] for mai menu : "))
        if x_conf == str("yes"):
            network_tools()

        else:
            from mltools import main

    if tools_number == str("splunk_info"):
      print("\nDesigned for both real-time analysis and historical data searches. Splunk is a fast and versatile network monitoring tool.\n"
      "One of the more user-friendly programs with a unified interface. Splunk’s strong search function makes application monitoring easy.\n"
      "Splunk is a paid app with free versions available.\n"
      "The free version is limited. This is an excellent tool to put on the list for those who have a budget to work with.\n"
      "Independent contractors tend to be careful about the premium tools they buy.\n"
      "Splunk is well worth the cost. Any information security professional with a strong enough client base should invest in Splunk.")
      print("\n")

      q_install3 =input(str("if want to download this tool enter [download] if not [no] : "))
      if q_install3 == str("download"):
        url = "https://mega.nz/file/NbhBBRjQ#tvVIx5h6qTn2gyF9cEWKXe-3cP96A6lFyAMR6qZZN9c"
        webbrowser.open(url)
        x_conf = str(input("do you to download more tools [yes] if you want [no] for mai menu : "))
        if x_conf == str("yes"):
            network_tools()

        else:
            from mltools import main

      else:
        network_tools()

tools_main()