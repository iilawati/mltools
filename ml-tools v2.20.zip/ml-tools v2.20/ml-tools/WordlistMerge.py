def sel():
    x = str(input('please confirm that you want to continue [y] : '))
    if x.lower() in ["y", "yes", "confirm"]:
        strat()
    else:
        sel()

def strat():
    def x_wordList():
        with open(file_name, "w") as output_file:
            for i in range(len(word2)):
                wordlist = word1 + word2[i]
                output_file.write(wordlist + "\n")

    def wordList_x():
        with open(file_name, "w") as output_file:
            for i in range(len(word2)):
                wordlist = word2[i] + word1
                output_file.write(wordlist + "\n")

    print("for [x] + [wordlist] (1)\n"
          "for [wordlist] + [x] (2)\n")
    wordlist_type = input(str("enter your wordlist type : "))

    if wordlist_type == str("1"):
        x_wordList()

    if wordlist_type == str("2"):
        wordList_x()


word1 = input(str("enter your word : "))

word2 = [line.strip() for line in open("custom.txt", 'r')]

file_name = input("your output file name ex(list.txt) : ")
sel()
