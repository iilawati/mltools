welcome to my tools to use my tools without any errors you need to install few python3 libraries and here the command to install 
[ pip install pip install requests validators colorama webbrowser]

and to use this tools just write this command [sudo pythony3 mltoos.py]

also note this tools has been developed for kali linux but it can work with any linux os for cybersecurity like parrot os , blackbox , deft zero 
