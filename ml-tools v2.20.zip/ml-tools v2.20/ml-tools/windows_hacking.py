import os

def windows_hacking_tools():
	os.system("clear")
	print ("kay logger (1)"
		"\n")
	tools_number1 = input(str("enter tools number : "))

	if tools_number1 == str("1"):
		kay_logger()

def kay_logger():
	os.system("clear")
	print("beelogger"
		"\ncromos")
	print("\n")
	kay_logger_name = input(str("enter the name : "))
	if kay_logger_name == str("beelogger"):
		os.system("git clone https://github.com/4w4k3/BeeLogger.git")
		kay_logger()

	if kay_logger_name == str("cromos"):
		os.system("git clone https://github.com/fbctf/cromos")
		kay_logger()
		
    


windows_hacking_tools()