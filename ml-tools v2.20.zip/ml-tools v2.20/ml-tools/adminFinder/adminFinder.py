import http.client
import requests
import validators
from http.client import responses
import colorama
from colorama import Fore, Style
import webbrowser

def sel():
    x = str(input('please confirm that you want to continue [y] : '))
    if x.lower() in ["y", "yes", "confirm"]:
        strat()
    else:
        sel()

def strat():
    with open("output.txt", "w") as output_file:
        for i in range(len(web_index_test)):
            url = web_url + web_index_test[i]
            if validators.url(url):
                status = requests.head(url).status_code
                if status == 200:
                    webbrowser.open(url)
                    output_file.write(url + "\n")
                    try:
                        print(Fore.BLUE + url, status, responses[status], "\n")
                        break
                    except:
                        print(url, status, "Not a standard HTTP response code\n")
                elif status == 302:
                    try:
                        print(Fore.GREEN + url, status, responses[status], "\n")
                    except:
                        print(url, status, "Not a standard HTTP response code\n")
                else:
                    print(Fore.RED + url, status, responses[status], "\n")
            else:
                print(url, "Not a valid URL\n")
                continue

print(Fore.GREEN + 'this tools made by mustafa lawati for any help feel free to contact via discord [itzacheron]\n')
web_url = input("enter url example [http://www.url.com/] : ")

web_index_test = [line.strip() for line in open("list.txt", 'r')]

sel()
