import os

def main():
    os.system("clear")

    print("welcome back hacker in my tool i hope to be useful "
          "\nfor any questions you can contact with me in facebook(https://www.facebook.com/mostafa.lawati)")
    print("\n")
    print("for kali update enter (1)\n"
          "for kali upgrade enter (2)\n"
          "for install some tools (3)\n"
          "for nmap scan (4)\n"
          "for setoolkit (5)\n"
          "for kali meta-packages menu (6)\n"
          "for kali meta-packages tools (7)\n"
          "to create your word list (8)\n"
          "for bruteforce attacks (9)\n"
          "to find any admin login page (10)\n"
          "to install and config NVIDIA GPU Drivers (11)\n"
          "for hash and password offline crack (12)")
    print("\n")
    random()



def random():
    random_x = input(str("enter your choice : "))
    if random_x == str("1"):
        kail_update()

    if random_x == str("2"):
        kail_upgrade()

    if random_x == str("3"):
        some_tools()

    if random_x == str("4"):
        namp_scan()

    if random_x == str("5"):
        setoolkit()

    if random_x == str("6"):
        metapackages_M()

    if random_x == str("7"):
        metapackages_T()

    if random_x == str("8"):
        wordlistC()

    if random_x == str("9"):
        bruteforce()

    if random_x == str("10"):
        adminF()

    if random_x == str("11"):
        NVIDIA()

    if random_x == str("12"):
        offline_cracker()

def kail_upgrade():
    print("welcome back hacker")
    upgrade = input(str("if you are want to upgrade your system enter [yes] if not enter [no] : "))
    if upgrade == str("yes"or"YES"or"Yes"):
        os.system("sudo apt-get upgrade -y")

        main()

    else:
        main()




def kail_update():
    print ("welcome back hacker")
    update = input(str("if you are want to update your system enter [yes] if not enter [no] : "))
    if update == str("yes"or"YES"or"Yes"):
        os.system("sudo apt-get update -y")
        c_upgrade = input(str("if you want to move to upgrade [yes] if not [no] : "))
        if c_upgrade == str("yes"or"Yes"or"YES"):
            kail_upgrade()

            main()
        else:
            main()
    else:
        main()


def some_tools():
    from tools import tools_main



def setoolkit():
    os.system("setoolkit")


def namp_scan():
    print("for stealth fast open tcp port and service version scan [1]\n"
          "to find all device on local network [2]\n"
          "for open tcp port scan [3]\n"
          "for open udp port scan [4]\n"
          "for open CVE Detecting [5]\n"
          "for WordPress brute force [6]\n"
          "for MS-SQL brute force [7]\n"
          "for FTP brute force [8]\n"
          "for Detecting malware [9]\n")

    scan_type = input(str("enter the type of your scan : "))

    if scan_type == str("1"):
        fast_scan()

    if scan_type == str("2"):
        local_scan()

    if scan_type == str("3"):
        TCP_scan()

    if scan_type == str("4"):
        UDP_scan()

    if scan_type == str("5"):
        CVE_scan()

    if scan_type == str("6"):
        WordPress_brute_force()

    if scan_type == str("7"):
        MS_SQL_brute_force()

    if scan_type == str("8"):
        FTP_brute_force()

    if scan_type == str("9"):
        Detecting_malware()

    else:
        namp_scan()


def local_scan():
    os.system("clear")
    os.system("ifconfig")
    print("\n")
    target = input("enter your router ip ex(192.168.0.1/24) :")
    os.system("sudo nmap -oN local-scan.txt -T4 -F ".__add__(target))
    print("\n")
    q_continue = int(input("enter 1 to scan ip  2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()
def fast_scan():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -F -sS -sV -O " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def TCP_scan():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -sT " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def UDP_scan():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -sU " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def CVE_scan():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -Pn --script vuln " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def WordPress_brute_force():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -sV --script http-wordpress-brute --script-args 'userdb=users.txt,passdb=passwds.txt,http-wordpress-brute.hostname=domain.com, http-wordpress-brute.threads=3,brute.firstonly=true'" .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def MS_SQL_brute_force():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap -p 1433 --script ms-sql-brute --script-args userdb=customuser.txt,passdb=custompass.txt " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def FTP_brute_force():
    os.system("clear")
    target = input("enter your target : ")
    os.system("sudo nmap --script ftp-brute -p 20,21,22,26,69,115,152,989,990 " .__add__( target))
    print("\n")
    q_continue = int(input("enter 1 to continue 2 for home page: "))
    if q_continue == 1:
        namp_scan()

    else:
        main()

def Detecting_malware():
    os.system("clear")
    print("for common malware scan [1] or Google’s Malware check [2] ")
    Detecting_malware_type = input("enter your detecting type : ")
    if Detecting_malware_type == "2":
        target = input("enter your target url :")
        os.system("sudo nmap -p80 --script http-google-malware ".__add__( target))

    if Detecting_malware_type == "1":
        target = input("enter your target ip :")
        os.system("sudo nmap -sV --script=http-malware-host ".__add__( target))


def metapackages_M():
    from kaliMetap_M import main

def metapackages_T():
    from kalitools import main

def wordlistC():
    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] or you want to merge two wordlist [merge] : "))
    if word_list_type == str("custom"):
        y = input("enter your list character : ")
        x_s = str(input('start num : '))
        x_e = str(input('end num : '))
        x_t = x_s + " " + x_e +" "+y
        print(x_t)
        os.system("crunch ".__add__(x_t) + " -o custom.txt")
        os.system("echo \" your wordlist have been saved in ml-tools folder \"")
        main()

    if word_list_type == str("word"):
        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
        x_s = str(input('start num : '))
        x_e = str(input('end num : '))
        x_t = x_s + " " + x_e + y
        print(x_t)
        os.system("crunch ".__add__(x_t) + " -o word.txt")
        os.system("echo \" your wordlist have been saved in ml-tools folder \"")
        main()

    if word_list_type == str("merge"):
        def sel():
            x = str(input('please confirm that you want to continue [y] : '))
            if x.lower() in ["y", "yes", "confirm"]:
                strat()
            else:
                sel()

        def strat():
            def x_wordList():
                with open(file_name, "w") as output_file:
                    for i in range(len(word2)):
                        wordlist = word1 + word2[i]
                        output_file.write(wordlist + "\n")


            def wordList_x():
                with open(file_name, "w") as output_file:
                    for i in range(len(word2)):
                        wordlist = word2[i] + word1
                        output_file.write(wordlist + "\n")


            print("for [x] + [wordlist] (1)\n"
                  "for [wordlist] + [x] (2)\n")
            wordlist_type = input(str("enter your wordlist type : "))

            if wordlist_type == str("1"):
                x_wordList()

            if wordlist_type == str("2"):
                wordList_x()

            else:
                wordlistC()

        word1 = input(str("enter your word : "))

        word2 = [line.strip() for line in open("custom.txt", 'r')]

        file_name = input("your output file name ex(list.txt) : ")
        sel()


    else:
        wordlistC()

def bruteforce():

    def ssh():
        user_name_Q = str(input("if you have the user name write [userK] if you dont have any info about user name write [userx] or if you have user name list write [list] : "))

        def user_as_list():
            userList = str(input("enter the user name list path like [/home/kali/Desktop/yourList.txt : "))
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

            def attack():
                os.system("hydra -s 22 -V -L".__add__(userList) + " -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o sshUserList.txt ".__add__(target_ip) + " ssh")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -L".__add__(userList) + " -P".__add__(wordlistPath)+ " -e ns -t 4 -o sshUserList.txt ".__add__(target_ip) + " ssh")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 22 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserList.txt ".__add__(target_ip) + " ssh")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 22 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserList.txt ".__add__(target_ip) + " ssh")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_UnKown():
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

            def attack():
                os.system("hydra -s 22 -V -L/usr/share/wordlists/rockyou.txt -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 22 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 22 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_know():
            user= str(input( "enter the user name : "))
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            def attack():
                os.system("hydra -s 22 -V -l ".__add__(user)+" -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o sshUserKnow.txt ".__add__(target_ip)+" ssh")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 22 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 22 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 22 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o sshUserUNKnow.txt ".__add__(target_ip) + " ssh")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                bruteforce()

        if user_name_Q == str("userK"):
            user_know()

        if user_name_Q == str("userx"):
            user_UnKown()

        if user_name_Q == str("list"):
            user_as_list()

    def ftp():
        user_name_Q = str(input("if you have the user name write [userK] if you dont have any info about user name write [userx] or if you have user name list write [list] : "))

        def user_as_list():
            userList = str(input("enter the user name list path like [/home/kali/Desktop/yourList.txt : "))
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

            def attack():
                os.system("hydra -s 21 -V -L".__add__(userList) + " -P/usr/share/wordlists/rockyou.txt -e ns -o ftpUserList.txt ".__add__(target_ip) + " ftp")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 21 -V -L".__add__(userList) + " -P".__add__(wordlistPath)+ " -e ns -o ftpUserList.txt ".__add__(target_ip) + " ftp")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 21 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserList.txt ".__add__(target_ip) + " ftp")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 21 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserList.txt ".__add__(target_ip) + " ftp")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_UnKown():
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

            def attack():
                os.system("hydra -s 21 -V -L/usr/share/wordlists/rockyou.txt -P/usr/share/wordlists/rockyou.txt -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftp")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 21 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftp")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 21 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftp")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 21 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftp")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_know():
            user= str(input( "enter the user name : "))
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            def attack():
                os.system("hydra -s 21 -V -l ".__add__(user)+" -P/usr/share/wordlists/rockyou.txt -e ns -o ftpUserKnow.txt ".__add__(target_ip)+" ftp")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 21 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftp")
                    main()
                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 21 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftp")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 21 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftp")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        if user_name_Q == str("userK"):
            user_know()

        if user_name_Q == str("userx"):
            user_UnKown()

        if user_name_Q == str("list"):
            user_as_list()



    def ftps():
        user_name_Q = str(input("if you have the user name write [userK] if you dont have any info about user name write [userx] or if you have user name list write [list] : "))

        def user_as_list():
            userList = str(input("enter the user name list path like [/home/kali/Desktop/yourList.txt : "))
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

            def attack():
                os.system("hydra -s 990 -V -L".__add__(userList) + " -P/usr/share/wordlists/rockyou.txt -e ns -o ftpUserList.txt ".__add__(target_ip) + " ftps")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 990 -V -L".__add__(userList) + " -P".__add__(wordlistPath)+ " -e ns -o ftpUserList.txt ".__add__(target_ip) + " ftps")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 990 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserList.txt ".__add__(target_ip) + " ftps")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 990 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserList.txt ".__add__(target_ip) + " ftps")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_UnKown():
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

            def attack():
                os.system("hydra -s 990 -V -L/usr/share/wordlists/rockyou.txt -P/usr/share/wordlists/rockyou.txt -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftps")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 990 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftps")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 990 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftps")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 990 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftps")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_know():
            user= str(input( "enter the user name : "))
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            def attack():
                os.system("hydra -s 990 -V -l ".__add__(user)+" -P/usr/share/wordlists/rockyou.txt -e ns -o ftpUserKnow.txt ".__add__(target_ip)+" ftps")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 990 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftps")
                    main()
                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 990 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftps")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 990 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -o ftpUserUNKnow.txt ".__add__(target_ip) + " ftps")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        if user_name_Q == str("userK"):
            user_know()

        if user_name_Q == str("userx"):
            user_UnKown()

        if user_name_Q == str("list"):
            user_as_list()

    def https_post():
        user_name_Q = str(input("if you have the user name write [userK] if you dont have any info about user name write [userx] or if you have user name list write [list] : "))

        def user_as_list():
            userList = str(input("enter the user name list path like [/home/kali/Desktop/yourList.txt : "))
            target_url = str(input("enter your target url : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            error_massage = str(input("enter your log in error massage withe login url [/admin.php:login body:error : "))

            def attack():
                os.system("hydra ".__add__(target_url) + " -s 443 -V -L".__add__(userList) + " -P/usr/share/wordlists/rockyou.txt -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserList.txt")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra ".__add__(target_url) + " -s 443 -V -L".__add__(userList) + " -P".__add__(wordlistPath)+ " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserList.txt")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 443 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserList.txt")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 443 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserList.txt")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_UnKown():
            target_url = str(input("enter your target url : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            error_massage = str(input("enter your log in error massage withe login url [/admin.php:login body:error : "))

            def attack():
                os.system("hydra ".__add__(target_url) +" -s 433 -V -L/usr/share/wordlists/rockyou.txt -P/usr/share/wordlists/rockyou.txt  -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserUnKnow.txt")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra ".__add__(target_url) + " -s 443 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserUnKnow.txt")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 443 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserUnKnow.txt")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 443 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserUnKnow.txt")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_know():
            user= str(input( "enter the user name : "))
            target_url = str(input("enter your target url : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            error_massage = str(input("enter your log in error massage withe login url [/admin.php:login body:error : "))
            def attack():
                os.system("hydra ".__add__(target_url) + " -s 433 -V -l ".__add__(user)+" -P/usr/share/wordlists/rockyou.txt -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserKnow.txt")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra ".__add__(target_url) + " -s 443 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserKnow.txt")
                    main()
                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 443 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserKnow.txt")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 443 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e nsr -t 16 https-post-form \"".__add__(error_massage)+"\" -o httpsPostUserKnow.txt")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        if user_name_Q == str("userK"):
            user_know()

        if user_name_Q == str("userx"):
            user_UnKown()

        if user_name_Q == str("list"):
            user_as_list()

    def http_post():
        user_name_Q = str(input("if you have the user name write [userK] if you dont have any info about user name write [userx] or if you have user name list write [list] : "))

        def user_as_list():
            userList = str(input("enter the user name list path like [/home/kali/Desktop/yourList.txt : "))
            target_url = str(input("enter your target url : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            error_massage = str(input("enter your log in error massage withe login url [/admin.php:login body:error : "))

            def attack():
                os.system("hydra ".__add__(target_url) + " -s 80 -V -L".__add__(userList) + " -P/usr/share/wordlists/rockyou.txt -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserList.txt")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra ".__add__(target_url) + " -s 80 -V -L".__add__(userList) + " -P".__add__(wordlistPath)+ " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserList.txt")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 80 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserList.txt")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 80 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserList.txt")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_UnKown():
            target_url = str(input("enter your target url : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            error_massage = str(input("enter your log in error massage withe login url [/admin.php:login body:error : "))

            def attack():
                os.system("hydra ".__add__(target_url) +" -s 80 -V -L/usr/share/wordlists/rockyou.txt -P/usr/share/wordlists/rockyou.txt  -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserUnKnow.txt")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra ".__add__(target_url) + " -s 80 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserUnKnow.txt")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 80 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserUnKnow.txt")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 80 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserUnKnow.txt")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_know():
            user= str(input( "enter the user name : "))
            target_url = str(input("enter your target url : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            error_massage = str(input("enter your log in error massage withe login url [/admin.php:login body:error : "))
            def attack():
                os.system("hydra ".__add__(target_url) + " -s 80 -V -l ".__add__(user)+" -P/usr/share/wordlists/rockyou.txt -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserKnow.txt")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra ".__add__(target_url) + " -s 80 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserKnow.txt")
                    main()
                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 80 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserKnow.txt")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra ".__add__(target_url) + " -s 80 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e nsr -t 16 http-post-form \"".__add__(error_massage)+"\" -o httpsPostUserKnow.txt")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        if user_name_Q == str("userK"):
            user_know()

        if user_name_Q == str("userx"):
            user_UnKown()

        if user_name_Q == str("list"):
            user_as_list()

    def RDP():
        user_name_Q = str(input("if you have the user name write [userK] if you dont have any info about user name write [userx] or if you have user name list write [list] : "))

        def user_as_list():
            userList = str(input("enter the user name list path like [/home/kali/Desktop/yourList.txt : "))
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

            def attack():
                os.system("hydra -s 3389 -V -L".__add__(userList) + " -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o rdpUserList.txt ".__add__(target_ip) + " rdp")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 3389 -V -L".__add__(userList) + " -P".__add__(wordlistPath)+ " -e ns -t 4 -o rdpUserList.txt ".__add__(target_ip) + " rdp")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 3389 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o rdpUserList.txt ".__add__(target_ip) + " rdp")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 3389 -V -L".__add__(userList) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o rdpUserList.txt ".__add__(target_ip) + " rdp")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_UnKown():
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))

            def attack():
                os.system("hydra -s 3389 -V -L/usr/share/wordlists/rockyou.txt -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o rdpUserUNKnow.txt ".__add__(target_ip) + " rdp")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 3389 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o rdpUserUNKnow.txt ".__add__(target_ip) + " rdp")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 3389 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o rdpUserUNKnow.txt ".__add__(target_ip) + " rdp")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 3389 -V -L".__add__(wordlistPath) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o rdpUserUNKnow.txt ".__add__(target_ip) + " rdp")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                main()

        def user_know():
            user= str(input( "enter the user name : "))
            target_ip = str(input("enter your target IP : "))
            rockyou_Q = str(input("did you use rockyou wordlist [yes] or [no] or you want to use you custom word list [custom] as pass list : "))
            def attack():
                os.system("hydra -s 3389 -V -l ".__add__(user)+" -P/usr/share/wordlists/rockyou.txt -e ns -t 4 -o rdpUserKnow.txt ".__add__(target_ip)+" rdp")
                main()

            def custom_word_list():
                q_for_wordlist = str(input("do you have custom word list [have] or you need to make one [make] : "))
                if q_for_wordlist == str('have'):
                    wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                    os.system("hydra -s 3389 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o rdpUserUNKnow.txt ".__add__(target_ip) + " rdp")
                    main()

                if q_for_wordlist == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + " " + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o custom.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 3389 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o rdpUserUNKnow.txt ".__add__(target_ip) + " rdp")
                        main()

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o word.txt")
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("hydra -s 3389 -V -l".__add__(user) + " -P".__add__(wordlistPath) + " -e ns -t 4 -o rdpUserUNKnow.txt ".__add__(target_ip) + " rdp")
                        main()

            if rockyou_Q == str("no"):
                os.system("cd /usr/share/wordlists")
                os.system("gzip -dv rockyou.txt.gz")
                attack()

            if rockyou_Q == str("yes"):
                attack()

            if rockyou_Q == str("custom"):
                custom_word_list()

            else:
                bruteforce()

        if user_name_Q == str("userK"):
            user_know()

        if user_name_Q == str("userx"):
            user_UnKown()

        if user_name_Q == str("list"):
            user_as_list()


    print("for ssh bruteforce [ssh]\n"
          "for ftp bruteforce [ftp]\n"
          "for ftps bruteforce [ftps]\n"
          "for https post form [https]\n"
          "for http post form [http]\n"
          "for remote desktop protocol [rdp]\n")

    attack_type = str(input("which type of bruteforce you want to use : "))

    if attack_type == str("ssh"):
        ssh()

    if attack_type == str("ftp"):
        ftp()

    if attack_type == str("ftps"):
        ftps()

    if attack_type == str("https"):
        https_post()

    if attack_type == str("http"):
        http_post()

    if attack_type == str("rdp"):
        RDP()

    else:
        main()
def adminF():
    os.system("clear")
    from adminFinder import adminFinder

def NVIDIA():
    os.system("lspci | grep -i vga")
    card_id = str(input("enter your card id ex(01:00.0) : "))
    os.system("lspci -s ".__add__(card_id)+" -v")
    os.system("sudo apt update && sudo apt install -y nvidia-driver nvidia-cuda-toolkit")
    os.system("sudo reboot -f")

def offline_cracker():
    os.system("clear")
    print("cracking password via john (1)\n"
          "cracking password via hashcat (2)\n")

    crack_type = input(str("enter your choice : "))

    if crack_type == str("1"):
        os.system("clear")
        print("welcome to john the repo\nhere menu of most password attack you can do with this tool\n"
              "for Single Crack Mode [1]\n"
              "for Dictionary Mode [2]\n"
              "for Incremental Mode [3]\n"
              "to Crack a Windows Password [4]\n"
              "to Crack a Linux Password [5]\n"
              "to Crack a Zip File Password [6]")

        attack_type = input(str("enter your choice : "))

        if attack_type == str("1"):
            C_OF_Type = input(str("did you know the hash type [md4 , md5 , etc...] answer [yes] if you know [no] if you didn't know : "))
            if C_OF_Type == str("yes"):
                os.system("clear")
                hash_type = input(str("enter the hash type : "))
                hash_file = input(str("enter the phat to your hash file ex[/home/kali/Desktop/hash.txt] : "))
                os.system("sudo john --single --format=".__add__(hash_type )+" ".__add__( hash_file))
            if C_OF_Type == str("no"):
                os.system("clear")
                print("note it will start an infinite loop after you find all hash type press[ctrl+c] to statr cracking")
                hash = input(str("enter the hash : "))
                os.system("hash-identifier ".__add__(hash))
                hash_type = input(str("enter the hash type : "))
                hash_file = input(str("enter the phat to your hash file ex[/home/kali/Desktop/hash.txt] : "))
                os.system("sudo john --single --format=".__add__(hash_type) + " ".__add__(hash_file))

        if attack_type == str("2"):
            C_OF_Type = input(str("did you know the hash type [md4 , md5 , etc...] answer [yes] if you know [no] if you didn't know : "))
            if C_OF_Type == str("yes"):
                os.system("clear")
                hash_type = input(str("enter the hash type : "))
                hash_file = input(str("enter the phat to your hash file ex[/home/kali/Desktop/hash.txt] : "))
                word_list_c = input(str("do you want to use rockyou as word list [yes] or you want to use custom wordlist [custom] or make wordlist [make] :"))
                if word_list_c == str("yes"):
                    os.system("sudo john --wordlist=/usr/share/wordlists/rockyou.txt --format=".__add__(hash_type )+" ".__add__( hash_file))

                if word_list_c == str("custom"):
                    word_list_p = input(str("enter your wordlist path : "))
                    os.system("sudo john --wordlist=".__add__(word_list_p)+" --format=".__add__(hash_type )+" ".__add__( hash_file))

                if word_list_c == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        list_name = input(str("enter the for your output file "))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o ".__add__(list_name))
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("sudo john --wordlist=".__add__(wordlistPath) + " --format=".__add__(hash_type) + " ".__add__(hash_file))

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        list_name = input(str("enter the for your output file "))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o ".__add__(list_name))
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("sudo john --wordlist=".__add__(wordlistPath) + " --format=".__add__(hash_type) + " ".__add__(hash_file))


            if C_OF_Type == str("no"):
                os.system("clear")
                print("note it will start an infinite loop after you find all hash type press[ctrl+c] to statr cracking")
                hash = input(str("enter the hash : "))
                os.system("hash-identifier ".__add__(hash))
                hash_type = input(str("enter the hash type : "))
                hash_file = input(str("enter the path to your hash file ex[/home/kali/Desktop/hash.txt] : "))
                word_list_c = input(str("do you want to use rockyou as word list [yes] or you want to use custom wordlist [custom] or make wordlist [make] :"))
                if word_list_c == str("yes"):
                    os.system("sudo john --wordlist=/usr/share/wordlists/rockyou.txt --format=".__add__(hash_type) + " ".__add__(hash_file))

                if word_list_c == str("custom"):
                    word_list_p = input(str("enter your wordlist path : "))
                    os.system(
                        "sudo john --wordlist=".__add__(word_list_p) + " --format=".__add__(hash_type) + " ".__add__(hash_file))

                if word_list_c == str("make"):
                    word_list_type = str(input("for custom wordlist [custom] or go with my wordlist [word] : "))

                    if word_list_type == str("custom"):
                        y = input("enter your list character : ")
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        list_name = input(str("enter the for your output file "))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o ".__add__(list_name))
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("sudo john --wordlist=".__add__(wordlistPath) + " --format=".__add__(hash_type) + " ".__add__(hash_file))

                    if word_list_type == str("word"):
                        y = ' QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890@-_.'
                        x_s = str(input('start num : '))
                        x_e = str(input('end num : '))
                        list_name = input(str("enter the for your output file "))
                        x_t = x_s + " " + x_e + y
                        print(x_t)
                        os.system("crunch ".__add__(x_t) + " -o ".__add__(list_name))
                        os.system("echo \"{your wordlist have been saved in ml-tools folder}\"")
                        wordlistPath = str(input("enter the pass list path like [/home/kali/Desktop/yourList.txt : "))
                        os.system("sudo john --wordlist=".__add__(wordlistPath) + " --format=".__add__(hash_type) + " ".__add__(hash_file))

    if attack_type == str("3"):
        os.system("clear")
        hash_file = input(str("enter the path to your hash file ex[/home/kali/Desktop/hash.txt] : "))
        os.system("sudo john -i:digits ".__add__( hash_file))

    if attack_type == str("4"):
        C_OF_Type = input(str("did you know the hash type [md4 , md5 , etc...] answer [yes] if you know [no] if you didn't know : "))
        if C_OF_Type == str("yes"):
            os.system("clear")
            hash_type = input(str("enter the hash type : "))
            hash_file = input(str("enter the path to your hash file ex[/home/kali/Desktop/hash.txt] : "))
            os.system("sudo john --single --format=".__add__(hash_type )+" ".__add__( hash_file))
        if C_OF_Type == str("no"):
            os.system("clear")
            print("note it will start an infinite loop after you find all hash type press[ctrl+c] to statr cracking")
            hash = input(str("enter the hash : "))
            os.system("hash-identifier ".__add__(hash))
            hash_type = input(str("enter the hash type : "))
            hash_file = input(str("enter the path to your hash file ex[/home/kali/Desktop/hash.txt] : "))
            os.system("sudo john --single --format=".__add__(hash_type) + " ".__add__(hash_file))

    if attack_type == str("5"):
        os.system("clear")
        os.system("sudo unshadow /etc/passwd /etc/shadow > output.db")
        os.system("sudo john output.db")

    if attack_type == str("6"):
        os.system("clear")
        zip_file_name = input(str("enter the zip file name : "))
        os.system("zip2john ".__add__(zip_file_name)+" > zip.hashes")
        os.system("john zip.hashes")

main()